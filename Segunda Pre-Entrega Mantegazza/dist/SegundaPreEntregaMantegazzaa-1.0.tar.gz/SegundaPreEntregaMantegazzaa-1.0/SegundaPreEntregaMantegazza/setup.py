from setuptools import setup

setup(
    
    name="SegundaPreEntregaMantegazzaa", 
    version="1.0",
    description="Segunda pre entrega",
    author="Tomas",
    author_email="tomaasmantegazza@gmail.com",
    
    packages=["SegundaPreEntregaMantegazza"]
)